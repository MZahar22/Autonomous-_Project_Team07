import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    pkg_dir = get_package_share_directory('autonomous_vehicle_team_7')

    return LaunchDescription([
# 1. Spawn the car [cite: 20, 39]
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_dir, 'launch', 'system_launch.py')),
            launch_arguments={
                'x': '5.0', 'y': '5.0', 'z': '0.5', 'yaw': '0.0' # Adjust per quadrant test 
            }.items()
        ),
        
        # 2. Speed Controller [cite: 41, 48]
        Node(
            package='autonomous_vehicle_team_7', executable='ms3_speed',
            parameters=[{'desired_speed': 8.0}, {'kp_speed': 0.8}]
        ),

        # 3. Lateral Controller (Main) [cite: 43, 64]
        Node(
            package='autonomous_vehicle_team_7', executable='ms3_lateral',
            parameters=[
                {'desired_lane_y': 10.0}, # Fixed target lane 
                {'k_stanley': 1.2}
            ]
        ),
        
        # 4. Automate Plot and Graph [cite: 45, 95]
        Node(package='rqt_graph', executable='rqt_graph'),
        Node(package='rqt_plot', executable='rqt_plot',
             arguments=['/diagnostics/cross_track_error/data', '/diagnostics/heading_error/data'])
    ])        
