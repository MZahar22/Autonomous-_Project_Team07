#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

class SpeedController(Node):
    def __init__(self):
        super().__init__('speed_controller_node')
        
        # 1. Declare ROS Parameters (Read from Launch File)
        self.declare_parameter('desired_speed', 5.0) 
        self.declare_parameter('kp_speed', 1.5)      
        
        # 2. Setup Publisher and Subscriber
        self.publisher_ = self.create_publisher(Twist, '/model/prius_hybrid/cmd_vel', 10)
        self.subscriber_ = self.create_subscription(Odometry, '/model/prius_hybrid/odometry', self.odom_callback, 10)
        
        self.cmd_msg = Twist()
        self.get_logger().info("Speed Controller (P-Control) Started!")

    def odom_callback(self, msg):
        desired_speed = self.get_parameter('desired_speed').value
        kp = self.get_parameter('kp_speed').value
        
        # Extract actual speed (assuming moving forward along X)
        actual_speed = msg.twist.twist.linear.x 
        
        # Calculate Error and apply Proportional Control
        error = desired_speed - actual_speed
        control_effort = kp * error
        
        # Publish Control Effort
        self.cmd_msg.linear.x = float(control_effort)
        self.publisher_.publish(self.cmd_msg)

def main(args=None):
    rclpy.init(args=args)
    node = SpeedController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
