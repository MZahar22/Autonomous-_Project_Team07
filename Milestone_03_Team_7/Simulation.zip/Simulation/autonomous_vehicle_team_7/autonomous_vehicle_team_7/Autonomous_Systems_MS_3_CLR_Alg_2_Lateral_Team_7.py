#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float32
import math

class FinalStanleyController(Node):
    def __init__(self):
        super().__init__('lateral_controller_node')
        
        # 1. Declare Parameters as required by MS03 [cite: 43, 74]
        self.declare_parameter('desired_lane_y', 0.0) 
        self.declare_parameter('k_stanley', 1.0) 
        
        # 2. Setup Pub/Sub
        self.publisher_ = self.create_publisher(Twist, '/model/prius_hybrid/cmd_vel', 10)
        self.subscriber_ = self.create_subscription(Odometry, '/model/prius_hybrid/odometry', self.odom_callback, 10)
        
        # 3. Diagnostic Publishers for rqt_plot 
        self.pub_cross_track = self.create_publisher(Float32, '/diagnostics/cross_track_error', 10)
        self.pub_heading = self.create_publisher(Float32, '/diagnostics/heading_error', 10)
        
        self.cmd_msg = Twist()
        self.get_logger().info("Final Stanley Controller (Main) is active.")

    def euler_from_quaternion(self, x, y, z, w):
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        return math.atan2(t3, t4)

    def odom_callback(self, msg):
        target_y = self.get_parameter('desired_lane_y').value
        k_stanley = self.get_parameter('k_stanley').value
        
        # --- State Extraction ---
        actual_y = msg.pose.pose.position.y
        cross_track_error = target_y - actual_y
        
        qx, qy, qz, qw = msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w
        actual_yaw = self.euler_from_quaternion(qx, qy, qz, qw)
        heading_error = 0.0 - actual_yaw 

        v_x = msg.twist.twist.linear.x
        v_x_capped = max(v_x, 0.5) # Soft cap for stability at low speeds

        # --- Stanley Law [cite: 68, 71] ---
        steering_effort = heading_error + math.atan2((k_stanley * cross_track_error), v_x_capped)
        steering_effort = max(min(steering_effort, 0.4), -0.4) 

        # --- Diagnostics ---
        msg_cte = Float32(); msg_cte.data = cross_track_error
        self.pub_cross_track.publish(msg_cte)
        msg_he = Float32(); msg_he.data = heading_error
        self.pub_heading.publish(msg_he)

        # --- Command Publishing [cite: 44] ---
        self.cmd_msg.linear.x = v_x 
        self.cmd_msg.angular.z = float(steering_effort)
        self.publisher_.publish(self.cmd_msg)

def main(args=None):
    rclpy.init(args=args)
    node = FinalStanleyController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
