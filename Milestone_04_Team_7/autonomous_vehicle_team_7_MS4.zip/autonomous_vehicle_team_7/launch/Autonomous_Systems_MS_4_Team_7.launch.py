import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_path = get_package_share_directory('autonomous_vehicle_team_7')
    world_file = os.path.join(pkg_path, 'Worlds', 'Empty_Track.world')

    # Path to the Prius model
    prius_model_path = os.path.join(
        os.path.expanduser('~'), 
        '.gz/fuel/fuel.ignitionrobotics.org/openrobotics/models/prius hybrid/3/model.sdf'
    )

    # 1. Start Gazebo immediately
    gz_sim = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )

    # 2. Group all other nodes to start AFTER Gazebo has fully loaded
    delayed_nodes = TimerAction(
        period=5.0,  # Wait 5 seconds for Gazebo physics to initialize
        actions=[
            # Spawn Car (Now explicitly targeting 'empty_track_world')
            Node(
                package='ros_gz_sim',
                executable='create',
                arguments=[
                    '-world', 'empty_track_world',
                    '-file', prius_model_path,
                    '-name', 'prius_hybrid',
                    '-x', '2.0',    # Moved 5 meters forward to avoid the back wall edge
                    '-y', '0.0', 
                    '-z', '0.1',    # Dropping from 2 meters high so the wheels don't clip the floor
	            '-Y' , '1.5708'
                ],
                output='screen'
            ),
            
            # Bridge
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=[
                    '/model/prius_hybrid/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                    '/model/prius_hybrid/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry'
                ],
                output='screen'
            ),
            
            # Planning Node
            Node(
                package='autonomous_vehicle_team_7',
                executable='planning_node',
                name='planning_node_team_7'
            ),
            
            # Speed Controller
            Node(
                package='autonomous_vehicle_team_7',
                executable='ms3_speed',
                name='speed_controller_node'
            ),
            
            # Lateral Controller
           # Node(
           #     package='autonomous_vehicle_team_7',
           #     executable='ms3_lateral',
           #     name='lateral_controller_node'
           # ),
            
            # rqt_graph
            Node(
                package='rqt_graph',
                executable='rqt_graph',
                name='rqt_graph'
            )
        ]
    )

    return LaunchDescription([
        gz_sim,
        delayed_nodes
    ])
