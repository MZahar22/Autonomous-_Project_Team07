import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_path = get_package_share_directory('autonomous_vehicle_team_7')
    
    # 1. POINT EXPLICITLY TO THE NEW RACING TRACK
    world_file = os.path.join(pkg_path, 'Worlds', 'City_Track.world')

    prius_model_path = os.path.join(
        os.path.expanduser('~'), 
        '.gz/fuel/fuel.ignitionrobotics.org/openrobotics/models/prius hybrid/3/model.sdf'
    )

    # 2. Start Gazebo
    gz_sim = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )

    # 3. Delayed Nodes
    delayed_nodes = TimerAction(
        period=5.0,
        actions=[
            # Spawner (Updated to spawn exactly in the new 0.0 bottom lane!)
            Node(
                package='ros_gz_sim',
                executable='create',
                arguments=[
                    '-world','city_track_world',
                    '-file', prius_model_path,
                    '-name', 'prius_hybrid',
                    '-x', '0.0', 
                    '-y', '0.0', 
                    '-z', '0.5',
                    '-Y', '1.5708'
                ],
                output='screen'
            ),
            
            # Bridge
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=[
                    '/model/prius_hybrid/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                    '/model/prius_hybrid/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry'
                ],
                output='screen'
            ),
            
            Node(package='autonomous_vehicle_team_7', executable='track3_planning', name='planner_track3'),
            Node(package='autonomous_vehicle_team_7', executable='ms3_speed', name='speed_ctrl'),
            Node(package='autonomous_vehicle_team_7', executable='ms3_lateral', name='lateral_ctrl'),
            Node(package='autonomous_vehicle_team_7', executable='combiner', name='combiner')
        ]
    )
    return LaunchDescription([
        gz_sim,
        delayed_nodes
    ])
