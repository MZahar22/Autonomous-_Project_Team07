import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_path = get_package_share_directory('autonomous_vehicle_team_7')
    world_file = os.path.join(pkg_path, 'Worlds', 'City_Track.world')

    prius_model_path = os.path.join(
        os.path.expanduser('~'), 
        '.gz/fuel/fuel.ignitionrobotics.org/openrobotics/models/prius hybrid/3/model.sdf'
    )

    # Launch Gazebo with the City World
    gz_sim = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )

    # Spawn the car after 5 seconds
    spawn_car = TimerAction(
        period=5.0,
        actions=[
            Node(
                package='ros_gz_sim',
                executable='create',
		arguments=[
                    '-world', 'city_track_world',
                    '-file', prius_model_path,
                    '-name', 'prius_hybrid',
                    '-x', '0.0', 
                    '-y', '-17.5',  # Moved to the center of the bottom lane!
                    '-z', '0.5',     # Safe drop height
		'-Y', '1.5708'	                ],
                output='screen'
            )
        ]
    )

    return LaunchDescription([gz_sim, spawn_car])
