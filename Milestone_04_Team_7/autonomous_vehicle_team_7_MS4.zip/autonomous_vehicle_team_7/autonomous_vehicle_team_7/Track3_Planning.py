#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry

class Track3Planner(Node):
    def __init__(self):
        super().__init__('planning_node_track3')
        self.speed_pub = self.create_publisher(Float64, '/desired_speed', 10)
        self.lane_pub = self.create_publisher(Float64, '/desired_lane', 10)
        self.heading_pub = self.create_publisher(Float64, '/desired_heading', 10) 
        self.odom_sub = self.create_subscription(Odometry, '/model/prius_hybrid/odometry', self.odom_callback, 10)
        
        self.state = 0
        self.print_counter = 0  
        self.get_logger().info("Track 3 Planner Started (Stabilization Zones Added)")

    def odom_callback(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        self.print_counter += 1
        if self.print_counter % 20 == 0:
            self.get_logger().info(f"Car Position -> X: {x:.2f} | Y: {y:.2f} | State: {self.state}")

        speed_msg = Float64()
        lane_msg = Float64()
        heading_msg = Float64()

        # ---------------------------------------------------------
        # PURE LOCAL STATE MACHINE - 30x40 Track Loop
        # ---------------------------------------------------------
        if self.state == 0:
            # Bottom Straight (East) - Perfect middle is y = 0.0
            lane_msg.data = 0.0; heading_msg.data = 0.0
            
            # Speed Control: Stabilize -> Cruise -> Brake
            if x < -10.0:
                speed_msg.data = 1.5  # Stabilize slowly after exiting Corner 4
            elif x >= 12.0:
                speed_msg.data = 1.2  # Brake early for Corner 1
            else:
                speed_msg.data = 3.0  # Cruise Speed
                
            if x >= 14.85: self.state = 1 # Anticipate physical steering delay
            
        elif self.state == 1:
            # Corner 1 (5m Radius)
            speed_msg.data = 1.2; lane_msg.data = 20.0; heading_msg.data = 1.5708
            if y >= 4.85: self.state = 2  # Anticipate physical steering delay
            
        elif self.state == 2:
            # Right Straight (North) - Perfect middle is x = 20.0
            lane_msg.data = 20.0; heading_msg.data = 1.5708
            
            # Speed Control: Stabilize -> Cruise -> Brake
            if y < 10.0:
                speed_msg.data = 1.5  # Stabilize slowly after exiting Corner 1
            elif y >= 16.0:
                speed_msg.data = 1.2  # Brake early for Corner 2
            else:
                speed_msg.data = 3.0
                
            if y >= 19.85: self.state = 3 # Anticipate physical steering delay
            
        elif self.state == 3:
            # Corner 2 (10m Radius)
            speed_msg.data = 1.6; lane_msg.data = 30.0; heading_msg.data = 3.1416
            if x <= 10.15: self.state = 4 # Anticipate physical steering delay
            
        elif self.state == 4:
            # Top Straight (West) - Perfect middle is y = 30.0
            lane_msg.data = 30.0; heading_msg.data = 3.1416
            
            # Speed Control: Stabilize -> Cruise -> Brake
            if x > 5.0:
                speed_msg.data = 1.5  # Stabilize slowly after exiting Corner 2
            elif x <= -6.0:
                speed_msg.data = 1.2  # Brake early for Corner 3
            else:
                speed_msg.data = 3.0
                
            if x <= -9.85: self.state = 5 # Anticipate physical steering delay
            
        elif self.state == 5:
            # Corner 3 (10m Radius)
            speed_msg.data = 1.6; lane_msg.data = -20.0; heading_msg.data = -1.5708
            if y <= 20.15: self.state = 6 # Anticipate physical steering delay
            
        elif self.state == 6:
            # Left Straight (South) - Perfect middle is x = -20.0
            lane_msg.data = -20.0; heading_msg.data = -1.5708
            
            # Speed Control: Stabilize -> Cruise -> Brake
            if y > 15.0:
                speed_msg.data = 1.5  # Stabilize slowly after exiting Corner 3
            elif y <= 9.0:
                speed_msg.data = 1.2  # Brake early for Corner 4
            else:
                speed_msg.data = 3.0
                
            if y <= 5.15: self.state = 7  # Anticipate physical steering delay
            
        elif self.state == 7:
            # Corner 4 (5m Radius)
            speed_msg.data = 1.2; lane_msg.data = 0.0; heading_msg.data = 0.0
            if x >= -14.85: self.state = 0 # Anticipate physical steering delay

        self.speed_pub.publish(speed_msg)
        self.lane_pub.publish(lane_msg)
        self.heading_pub.publish(heading_msg)

def main(args=None):
    rclpy.init(args=args)
    node = Track3Planner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
