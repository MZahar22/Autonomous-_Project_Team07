#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class CombiningNode(Node):
    def __init__(self):
        super().__init__('combining_control_node')
        self.publisher_ = self.create_publisher(Twist, '/model/prius_hybrid/cmd_vel', 10)
        
        # Subscribes to raw outputs from separate controllers
        self.speed_sub = self.create_subscription(Twist, '/speed_cmd_raw', self.speed_callback, 10)
        self.steering_sub = self.create_subscription(Twist, '/steering_cmd_raw', self.steering_callback, 10)
        
        self.final_cmd = Twist()
        self.create_timer(0.02, self.publish_combined) # 50Hz

    def speed_callback(self, msg):
        self.final_cmd.linear.x = msg.linear.x

    def steering_callback(self, msg):
        self.final_cmd.angular.z = msg.angular.z

    def publish_combined(self):
        self.publisher_.publish(self.final_cmd)

def main(args=None):
    rclpy.init(args=args)
    node = CombiningNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
