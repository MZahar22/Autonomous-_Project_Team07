#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class Track1Planner(Node):
    def __init__(self):
        super().__init__('planning_node_team_7')

        # Publishers for desired speed (Longitudinal) and desired lane (Lateral)
        # UPDATE THESE TOPIC NAMES to match your MS 2 control nodes
        self.speed_pub = self.create_publisher(Float64, '/desired_speed', 10)
        self.lane_pub = self.create_publisher(Float64, '/desired_lane', 10)

        # Publish continuously at 10 Hz
        self.timer = self.create_timer(0.1, self.publish_plan)

    def publish_plan(self):
        # Track 01: Move straight with no maneuvers
        speed_msg = Float64()
        speed_msg.data = 1.0  # 1.0 m/s forward speed

        lane_msg = Float64()
        lane_msg.data = 0.0   # 0.0 meters lateral offset (stay center)

        self.speed_pub.publish(speed_msg)
        self.lane_pub.publish(lane_msg)

def main(args=None):
    rclpy.init(args=args)
    node = Track1Planner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
