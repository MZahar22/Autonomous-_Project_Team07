#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

class SpeedController(Node):
    def __init__(self):
        super().__init__('speed_controller_node')
        
        # INCREASED KP for more torque to overcome steering friction
        self.declare_parameter('kp_speed', 2.0)      
        
        self.publisher_ = self.create_publisher(Twist, '/speed_cmd_raw', 10)
        self.subscriber_ = self.create_subscription(Odometry, '/model/prius_hybrid/odometry', self.odom_callback, 10)
        self.planner_sub = self.create_subscription(Float64, '/desired_speed', self.planner_callback, 10)
        
        self.cmd_msg = Twist()
        self.last_control_effort = 0.0
        self.start_x = None
        self.reached_goal = False
        self.target_speed = 0.0  

    def planner_callback(self, msg):
        self.target_speed = msg.data

    def odom_callback(self, msg):
        curr_x = msg.pose.pose.position.x
        if self.start_x is None:
            self.start_x = curr_x
            return

        distance_traveled = abs(curr_x - self.start_x)

        if distance_traveled >= 105.0 or self.reached_goal:
            if not self.reached_goal:
                self.get_logger().info("TRACK COMPLETE!")
                self.reached_goal = True
            self.cmd_msg.linear.x = 0.0
            self.publisher_.publish(self.cmd_msg)
            return 

        kp = self.get_parameter('kp_speed').value
        actual_speed = msg.twist.twist.linear.x 
        
        error = self.target_speed - actual_speed
        raw_target = kp * error
        
        # INCREASED RAMP STEP so it applies power faster when bogged down
        ramp_step = 0.2 
        if raw_target > self.last_control_effort + ramp_step:
            control_effort = self.last_control_effort + ramp_step
        elif raw_target < self.last_control_effort - ramp_step:
            control_effort = self.last_control_effort - ramp_step
        else:
            control_effort = raw_target

        # INCREASED MAX CAP so the car is allowed to use more force
        control_effort = max(min(control_effort, 8.0), -2.0)
        self.last_control_effort = control_effort
        
        self.cmd_msg.linear.x = float(control_effort)
        self.publisher_.publish(self.cmd_msg)

def main(args=None):
    rclpy.init(args=args)
    node = SpeedController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
