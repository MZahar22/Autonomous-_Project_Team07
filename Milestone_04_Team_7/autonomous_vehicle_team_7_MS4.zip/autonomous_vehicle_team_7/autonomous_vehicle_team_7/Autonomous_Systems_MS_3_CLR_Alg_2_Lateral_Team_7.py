#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float32, Float64
import math

class FinalStanleyController(Node):
    def __init__(self):
        super().__init__('lateral_controller_node')
        self.declare_parameter('k_stanley', 1.5) 
        
        self.publisher_ = self.create_publisher(Twist, '/steering_cmd_raw', 10)
        self.subscriber_ = self.create_subscription(Odometry, '/model/prius_hybrid/odometry', self.odom_callback, 10)
        
        self.planner_sub = self.create_subscription(Float64, '/desired_lane', self.lane_callback, 10)
        self.heading_sub = self.create_subscription(Float64, '/desired_heading', self.heading_callback, 10)
        
        self.cmd_msg = Twist()
        self.target_lane = 0.0    
        self.target_yaw = 0.0     

    def lane_callback(self, msg):
        self.target_lane = msg.data

    def heading_callback(self, msg):
        self.target_yaw = msg.data

    def euler_from_quaternion(self, x, y, z, w):
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        return math.atan2(t3, t4)

    def odom_callback(self, msg):
        actual_x = msg.pose.pose.position.x
        actual_y = msg.pose.pose.position.y
        
        qx, qy, qz, qw = msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w
        actual_yaw = self.euler_from_quaternion(qx, qy, qz, qw)
        
        in_corner = False
        cx, cy, radius = 0.0, 0.0, 0.0

        # DETERMINE IF CAR IS IN ONE OF THE 4 CORNERS
        if actual_x >= 15.0 and actual_y <= 5.0:       # Corner 1: Bottom Right (5m Radius)
            in_corner = True; cx, cy, radius = 15.0, 5.0, 5.0
        elif actual_x >= 10.0 and actual_y >= 20.0:    # Corner 2: Top Right (10m Radius)
            in_corner = True; cx, cy, radius = 10.0, 20.0, 10.0
        elif actual_x <= -10.0 and actual_y >= 20.0:   # Corner 3: Top Left (10m Radius)
            in_corner = True; cx, cy, radius = -10.0, 20.0, 10.0
        elif actual_x <= -15.0 and actual_y <= 5.0:    # Corner 4: Bottom Left (5m Radius)
            in_corner = True; cx, cy, radius = -15.0, 5.0, 5.0

        # CALCULATE ERRORS NATIVELY
        if in_corner:
            # ARC TRACKING MODE (Continuous smooth turning)
            distance_to_center = math.sqrt((actual_x - cx)**2 + (actual_y - cy)**2)
            cross_track_error = distance_to_center - radius
            # Tangent angle of the circle at car's current position
            active_target_yaw = math.atan2(actual_y - cy, actual_x - cx) + (math.pi / 2.0)
        else:
            # STRAIGHT LINE TRACKING MODE
            active_target_yaw = self.target_yaw
            if abs(self.target_yaw) < 0.5:                  # East
                cross_track_error = self.target_lane - actual_y
            elif abs(self.target_yaw - 1.5708) < 0.5:       # North
                cross_track_error = actual_x - self.target_lane
            elif abs(abs(self.target_yaw) - 3.1416) < 0.5:  # West
                cross_track_error = actual_y - self.target_lane
            else:                                           # South
                cross_track_error = self.target_lane - actual_x

        # Calculate Final Heading Error
        heading_error = active_target_yaw - actual_yaw
        heading_error = math.atan2(math.sin(heading_error), math.cos(heading_error))

        # STANDARD STANLEY KINEMATICS (Works smoothly for both lines and arcs!)
        v_x = max(msg.twist.twist.linear.x, 1.0) 
        k_stanley = self.get_parameter('k_stanley').value
        
        steering_effort = heading_error + math.atan2((k_stanley * cross_track_error), v_x)
        steering_effort = max(min(steering_effort, 0.8), -0.8) 

        self.cmd_msg.angular.z = float(steering_effort)
        self.cmd_msg.linear.x = 0.0 
        self.publisher_.publish(self.cmd_msg)

def main(args=None):
    rclpy.init(args=args)
    node = FinalStanleyController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
