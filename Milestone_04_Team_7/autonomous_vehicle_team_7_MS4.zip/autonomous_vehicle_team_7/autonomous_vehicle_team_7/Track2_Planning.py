#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry

class Track2Planner(Node):
    def __init__(self):
        super().__init__('planning_node_track2')
        self.speed_pub = self.create_publisher(Float64, '/desired_speed', 10)
        self.lane_pub = self.create_publisher(Float64, '/desired_lane', 10)
        self.odom_sub = self.create_subscription(Odometry, '/model/prius_hybrid/odometry', self.odom_callback, 10)
        
        self.start_x = None
        self.get_logger().info("Track 2 Planner Active: 10m Straight -> Turn -> Opposite Turn")

    def odom_callback(self, msg):
        curr_x = msg.pose.pose.position.x
        if self.start_x is None:
            self.start_x = curr_x
            return
        
        dist = abs(curr_x - self.start_x)
        speed_msg = Float64()
        lane_msg = Float64()

        # YOUR REQUESTED PATH
        if dist < 10.0:
            # 1. Move 10m straight down the middle
            speed_msg.data = 3.0   
            lane_msg.data = 0.0    
        elif dist < 30.0:
            # 2. Begin to turn (Lane 1)
            speed_msg.data = 3.0    
            lane_msg.data = 1.875  
        elif dist < 50.0:
            # 3. Turn again to the opposite side (Lane 2)
            speed_msg.data = 3.0    
            lane_msg.data = -1.875  
        else:
            # 4. Continue straight
            speed_msg.data = 3.0    
            lane_msg.data = -1.875  

        self.speed_pub.publish(speed_msg)
        self.lane_pub.publish(lane_msg)

def main(args=None):
    rclpy.init(args=args)
    node = Track2Planner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
