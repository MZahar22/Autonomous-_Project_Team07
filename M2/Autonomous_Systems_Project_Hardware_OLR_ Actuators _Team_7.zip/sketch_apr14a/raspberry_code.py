import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial

class HardwareBridgeNode(Node):
    def __init__(self):
        super().__init__('hardware_bridge')
        self.get_logger().info("Hardware Bridge Started! Connecting to Arduino...")
        
        # Connect to the Arduino via USB. 
        # (Note: this might be /dev/ttyACM0 or /dev/ttyUSB0 depending on the Pi)
        try:
            self.arduino = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)
            self.get_logger().info("Successfully connected to Arduino!")
        except Exception as e:
            self.get_logger().error(f"Failed to connect to Arduino: {e}")
            return

        # Subscribe to the Teleop keyboard commands
        self.subscriber_ = self.create_subscription(
            Twist, 
            '/cmd_vel', 
            self.cmd_vel_callback, 
            10
        )

    def cmd_vel_callback(self, msg):
        # 1. Map ROS 2 Linear Velocity (e.g., -5.0 to 5.0) to Arduino PWM (-255 to 255)
        # You will need to tune this multiplier based on how fast your physical car is
        speed_pwm = int(msg.linear.x * 50) 
        
        # Clamp PWM to safe limits
        speed_pwm = max(-255, min(255, speed_pwm)) 
        
        # 2. Map ROS 2 Angular Velocity (e.g., -1.0 to 1.0) to Servo Angle (0 to 180, 90 is straight)
        # If turning left (positive Z), subtract angle. If turning right, add angle.
        steering_angle = int(90 - (msg.angular.z * 45))
        
        # Clamp angle to safe limits (prevent breaking the physical steering rack)
        steering_angle = max(45, min(135, steering_angle)) 

        # 3. Format the message for the Arduino: "SPEED,ANGLE\n"
        command_string = f"{speed_pwm},{steering_angle}\n"
        
        # 4. Send it down the USB cable!
        self.arduino.write(command_string.encode('utf-8'))
        self.get_logger().info(f"Sent to Arduino: {command_string.strip()}")

def main(args=None):
    rclpy.init(args=args)
    node = HardwareBridgeNode()
    if hasattr(node, 'arduino'): # Only run if serial connected
        rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
