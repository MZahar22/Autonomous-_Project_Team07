// Motor Connections
const int enA = 9;
const int in1 = 8;
const int in2 = 7;

void setup() {
  // 115200 is a fast, reliable baud rate commonly used with ROS 2 setups
  Serial.begin(115200); 
  
  pinMode(enA, OUTPUT);
  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  
  // Ensure the motor is off at startup
  digitalWrite(in1, LOW);
  digitalWrite(in2, LOW);
  analogWrite(enA, 0);
}

void loop() {
  // Check if the Raspberry Pi sent anything
  if (Serial.available() > 0) {
    // Read the incoming data until it sees a newline character
    String command = Serial.readStringUntil('\n');
    command.trim(); // Remove any stray whitespace
    
    int speed = command.toInt(); // Convert string to integer (-255 to 255)
    
    if (speed > 0) {
      // Forward
      digitalWrite(in1, HIGH);
      digitalWrite(in2, LOW);
      analogWrite(enA, speed);
    } 
    else if (speed < 0) {
      // Backward
      digitalWrite(in1, LOW);
      digitalWrite(in2, HIGH);
      // analogWrite only takes positive numbers, so use abs()
      analogWrite(enA, abs(speed)); 
    } 
    else {
      // Stop (Brake)
      digitalWrite(in1, LOW);
      digitalWrite(in2, LOW);
      analogWrite(enA, 0);
    }
  }
}