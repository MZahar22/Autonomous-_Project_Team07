import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'autonomous_vehicle_team_7'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # THIS IS THE NEW LINE THAT INSTALLS THE LAUNCH FOLDER
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='master-pke',
    maintainer_email='master-pke@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'olr_node = autonomous_vehicle_team_7.prius_OLR:main',
            'teleop_node = autonomous_vehicle_team_7.prius_Teleop:main'
        ],
    },
)
