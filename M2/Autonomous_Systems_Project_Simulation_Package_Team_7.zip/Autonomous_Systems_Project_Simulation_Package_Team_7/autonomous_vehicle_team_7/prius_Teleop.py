import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import sys
import termios
import tty

class TeleopNode(Node):
    def __init__(self):
        super().__init__('teleop_node')
        self.publisher_ = self.create_publisher(Twist, '/model/prius_hybrid/cmd_vel', 10)
        self.get_logger().info("Teleop Node Started! Use W/A/S/D to drive. Spacebar to brake. Press 'q' to quit.")

        # Set the vehicle's top speed and turning sharpness
        self.speed = 5.0
        self.turn = 1.0

        # Save the terminal's default settings so we don't break it
        self.settings = termios.tcgetattr(sys.stdin)

    # This function hijacks the keyboard so we don't have to press 'Enter'
    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        key = sys.stdin.read(1)
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def run(self):
        msg = Twist()
        try:
            while True:
                key = self.get_key()
                
                # The Event Listener (Mapping keys to movement)
                if key == 'w':
                    msg.linear.x = self.speed
                    msg.angular.z = 0.0
                elif key == 's':
                    msg.linear.x = -self.speed
                    msg.angular.z = 0.0
                elif key == 'a':
                    msg.linear.x = self.speed  # Keep moving forward
                    msg.angular.z = self.turn  # But turn left
                elif key == 'd':
                    msg.linear.x = self.speed  # Keep moving forward
                    msg.angular.z = -self.turn # But turn right
                elif key == ' ':
                    msg.linear.x = 0.0         # Slam the brakes
                    msg.angular.z = 0.0
                elif key == 'q':
                    break                      # Quit the program
                else:
                    continue                   # Ignore any other keys
                
                # Shout the command to the car
                self.publisher_.publish(msg)
                
        except Exception as e:
            print(e)
        finally:
            # Safety feature: Tell the car to stop before the script closes
            msg.linear.x = 0.0
            msg.angular.z = 0.0
            self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    node.run()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
