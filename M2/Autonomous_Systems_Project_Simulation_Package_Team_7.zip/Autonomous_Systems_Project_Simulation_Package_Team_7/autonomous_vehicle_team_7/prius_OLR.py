import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import math

class OpenLoopNode(Node):
    def __init__(self):
        super().__init__('olr_node')
        self.get_logger().info("Figure-8 OLR Node Started! (With Position Tracking)")
        
        # The Publisher (Megaphone) and Subscriber (Ears)
        self.publisher_ = self.create_publisher(Twist, '/model/prius_hybrid/cmd_vel', 10)
        self.subscriber_ = self.create_subscription(Odometry, '/model/prius_hybrid/odometry', self.odom_callback, 10)
        
        # --- The Figure-8 Kinematics ---
        self.timer_period = 0.1  # Metronome ticks 10 times a second
        self.linear_speed = 4.0  # Forward speed (m/s)
        self.angular_speed = 0.6 # Turning speed (rad/s)
        self.direction = 1.0     # 1.0 is Left (CCW), -1.0 is Right (CW)
        
        # Calculate exactly how many ticks it takes to complete one full 360-degree circle
        time_for_one_circle = (2 * math.pi) / self.angular_speed
        self.ticks_per_circle = int(time_for_one_circle / self.timer_period)
        
        self.current_tick = 0
        
        # Start the Timer
        self.timer = self.create_timer(self.timer_period, self.timer_callback)

    # 1. The Brain: Calculates when to steer
    def timer_callback(self):
        msg = Twist()
        
        # Check if we have completed a full circle
        self.current_tick += 1
        if self.current_tick >= self.ticks_per_circle:
            # Flip the steering wheel to the opposite direction
            self.direction *= -1.0 
            # Reset the counter for the next circle
            self.current_tick = 0
            self.get_logger().info("\n---> SWITCHING DIRECTION! <--- \n")

        # Drive the car
        msg.linear.x = self.linear_speed
        msg.angular.z = self.angular_speed * self.direction
        self.publisher_.publish(msg)

# 2. The Eyes: Reads position from Gazebo
    def odom_callback(self, msg):
        # Position
        pos_x = msg.pose.pose.position.x
        pos_y = msg.pose.pose.position.y
        
        # --- CALCULATING GLOBAL VELOCITY ---
        
        # A. Get the orientation quaternion
        q = msg.pose.pose.orientation
        
        # B. Convert the quaternion to a Yaw angle (in radians)
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        
        # C. Get the local velocities (Notice the .twist.twist path!)
        local_v_x = msg.twist.twist.linear.x
        angular_z = msg.twist.twist.angular.z
        
        # D. Convert local velocity to global velocity
        global_v_x = local_v_x * math.cos(yaw)
        global_v_y = local_v_x * math.sin(yaw)
        
        # --- LOGGING ---
        steering_status = "Left" if self.direction > 0 else "Right"
        
        self.get_logger().info(
            f'\nPos: [X: {pos_x:.2f}, Y: {pos_y:.2f}] | Turning: {steering_status}\n'
            f'Local Speed: {local_v_x:.2f} m/s | Angular Z: {angular_z:.2f} rad/s\n'
            f'Global Velocity: [Vx: {global_v_x:.2f} m/s, Vy: {global_v_y:.2f} m/s]'
        )

def main(args=None):
    rclpy.init(args=args)
    node = OpenLoopNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
