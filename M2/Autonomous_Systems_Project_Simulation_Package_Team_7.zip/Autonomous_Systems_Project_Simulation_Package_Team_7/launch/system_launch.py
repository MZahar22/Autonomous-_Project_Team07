import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

def generate_launch_description():
    # Use expanduser to automatically find the correct home directory (/home/master-pke)
    prius_model_path = os.path.join(
        os.path.expanduser('~'), 
        '.gz/fuel/fuel.ignitionrobotics.org/openrobotics/models/prius hybrid/3/model.sdf'
    )

    return LaunchDescription([
        # 1. Turn on the World (Gazebo) and auto-play (-r)
        ExecuteProcess(
            cmd=['gz', 'sim', '-r', 'empty.sdf'],
            output='screen'
        ),
        
        # 2. Spawn the custom Prius from your local hard drive
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=[
                '-file', prius_model_path,
                '-name', 'prius_hybrid',
                '-x', '0.0', '-y', '0.0', '-z', '0.5'
            ],
            output='screen'
        ),
        
        # 3. Build the Bridge
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/prius_hybrid/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                '/model/prius_hybrid/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry'
            ],
            output='screen'
        )
    ])
